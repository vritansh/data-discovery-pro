import matplotlib.pyplot as plt
import pandas as pd
import configparser

class DataCleaner():
     def __init__(self):
         self.config = configparser.ConfigParser()

     def handle_missing_values(self, df):
         pass


